Provides an ingame technology browser.
It is a simple help system. With H (configurable) you get to an item what it is made of and where it is needed. This works in a lot of different places (unfortunately not in all of them). In the help system you can get more information about the items with one click. 
There is also a history.

It is a tribute to the help system of Evospace. I hope factorio players will like it a lot as well.
Unfortunately, the places where you can look up information about an item are not as comprehensive as in the above mentioned game, because factorio does not provide the appropriate mouse events everywhere. 
This release is only the first stage. I have more ideas for extensions. I am also open for suggestions. I am especially happy about further places where I can connect the help system.

todo:
- selection from multi-item-entities
- Sort-performance
- Load-performance resp. progress information
- migration-awareness
- copy recipe 
- provide information on recipe-combinations
- restrict number of lines; provide expand-button
- tooltip-help and actual keys should be joined
- provide summary for recipe like in tooltip from crafting menu
- help on about modules
- help on fuel consumption
- help on recipes
- help on technologies
- multiplayer
- involve achievements
- "machine-column" for character
- machine-column for labs

known issue: 
- it takes seconds when presenting first help page
- it takes seconds when presenting large help pages the first time
- it takes second when presenting large help pages (especially machine-columns)
- Water -> steam is missing


